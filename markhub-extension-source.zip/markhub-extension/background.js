/**
 * MarkHub 浏览器扩展 - 后台脚本
 * 负责管理右键菜单、接收消息并转发到MarkHub应用
 */

// 在扩展安装时创建右键菜单
chrome.runtime.onInstalled.addListener(() => {
  // 清除之前可能存在的菜单项，防止重复
  chrome.contextMenus.removeAll(() => {
    // 创建新的菜单项
    chrome.contextMenus.create({
      id: "addToMarkHub",
      title: "添加到MarkHub",
      contexts: ["page", "link"]
    });
  });
});

// 用于跟踪弹窗状态的变量
let popupWindowId = null;

// 监听右键菜单点击
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "addToMarkHub") {
    // 获取URL和标题
    const url = info.linkUrl || tab.url;
    const title = tab.title || url;

    // 如果已经有弹窗打开，先关闭它
    if (popupWindowId !== null) {
      chrome.windows.remove(popupWindowId, () => {
        // 忽略可能的错误
        if (chrome.runtime.lastError) {
          console.log("关闭旧弹窗时出错:", chrome.runtime.lastError.message);
        }
        popupWindowId = null;
      });
    }

    // 打开弹窗并传递URL和标题作为参数
    let popupURL = chrome.runtime.getURL("popup/popup.html") +
                  `?url=${encodeURIComponent(url)}&title=${encodeURIComponent(title)}&source=contextmenu`;

    chrome.windows.create({
      url: popupURL,
      type: "popup",
      width: 350,
      height: 380
    }, (window) => {
      // 保存弹窗ID以便后续管理
      if (window) {
        popupWindowId = window.id;

        // 监听弹窗关闭事件
        chrome.windows.onRemoved.addListener(function windowClosedListener(windowId) {
          if (windowId === popupWindowId) {
            popupWindowId = null;
            // 移除监听器，避免内存泄漏
            chrome.windows.onRemoved.removeListener(windowClosedListener);
          }
        });
      }
    });
  }
});

// 监听来自popup.js的消息
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.action === "saveBookmark") {
    saveBookmarkToMarkHub(message.bookmark, sendResponse);
    return true; // 保持消息通道打开以支持异步sendResponse
  }
});

/**
 * 尝试将书签保存到MarkHub应用
 * 如果应用已打开，则直接发送消息
 * 否则将书签保存到storage以便下次打开应用时添加
 */
async function saveBookmarkToMarkHub(bookmark, sendResponse) {
  try {
    // 查找已打开的MarkHub应用标签页（包括生产环境和本地开发环境）
    const tabs = await chrome.tabs.query({ url: ["*://markhub.app/*", "http://localhost:3000/*"] });

    if (tabs.length > 0) {
      // MarkHub应用已打开，发送消息
      try {
        await chrome.tabs.sendMessage(tabs[0].id, {
          type: "MARKHUB_EXTENSION_ADD_BOOKMARK",
          bookmark
        });
        sendResponse({
          success: true,
          message: "书签已发送到MarkHub应用"
        });
      } catch (error) {
        // 发送消息失败，执行备用方案
        await saveBookmarkToStorage(bookmark);
        sendResponse({
          success: true,
          message: "书签已暂存，将在下次打开MarkHub时添加",
          pending: true
        });
      }
    } else {
      // MarkHub应用未打开，执行备用方案
      await saveBookmarkToStorage(bookmark);
      sendResponse({
        success: true,
        message: "书签已暂存，将在下次打开MarkHub时添加",
        pending: true
      });
    }
  } catch (error) {
    // 处理错误
    console.error("保存书签失败:", error);
    sendResponse({
      success: false,
      error: `保存书签失败: ${error.message}`
    });
  }
}

/**
 * 将书签保存到chrome.storage.local中（备用方案）
 * 使用新的键名和确保数据结构完整性
 */
async function saveBookmarkToStorage(bookmark) {
  try {
    // 确保书签对象包含所需字段
    const processedBookmark = {
      ...bookmark,
      url: bookmark.url || "",
      title: bookmark.title || "",
      createdAt: bookmark.createdAt || new Date().toISOString(),
      timestamp: new Date().getTime(),
      tags: bookmark.tags || [],
      description: bookmark.description || ""
    };

    // 使用更明确的键名获取现有的暂存书签
    const storageKey = "markhub_pending_ai_bookmarks";
    const data = await chrome.storage.local.get(storageKey);
    let pendingBookmarks = data[storageKey] || [];

    // 添加新书签
    pendingBookmarks.push(processedBookmark);

    // 保存更新后的书签数组
    await chrome.storage.local.set({ [storageKey]: pendingBookmarks });
    console.log(`书签已暂存到chrome.storage.local，共${pendingBookmarks.length}个待处理书签`);

    // 同时保持与旧版本兼容，也保存到原来的键下
    const oldData = await chrome.storage.local.get("pendingBookmarks");
    let oldPendingBookmarks = oldData.pendingBookmarks || [];
    oldPendingBookmarks.push(processedBookmark);
    await chrome.storage.local.set({ pendingBookmarks: oldPendingBookmarks });
  } catch (error) {
    console.error("保存书签到存储失败:", error);
    throw error;
  }
}