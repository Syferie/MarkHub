/**
 * MarkHub 浏览器扩展 - 内容脚本
 * 负责在MarkHub应用页面中接收来自扩展的消息并转发给应用
 */

// 监听来自 background.js 的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  try {
    if (message.type === "MARKHUB_EXTENSION_ADD_BOOKMARK") {
      // 收到书签数据，转发给MarkHub应用页面，使用新的消息类型支持AI自动分类
      window.postMessage({
        type: "NEW_BOOKMARK_FOR_AI_CLASSIFICATION",
        payload: {
          url: message.bookmark.url,
          title: message.bookmark.title,
          addedAt: message.bookmark.createdAt || new Date().toISOString(),
          tags: message.bookmark.tags || [],
          description: message.bookmark.description || ""
        },
        source: "markhub-extension"
      }, "*");
      
      // 发送成功响应
      if (sendResponse) {
        sendResponse({ success: true });
      }
    } else if (message.type === "MARKHUB_EXTENSION_SAVE_TO_LOCALSTORAGE") {
      // 作为备用方案，将书签数据保存到localStorage
      try {
        const existingData = localStorage.getItem(message.key);
        let bookmarks = [];
        
        if (existingData) {
          bookmarks = JSON.parse(existingData);
          if (!Array.isArray(bookmarks)) {
            bookmarks = [];
          }
        }
        
        // 添加新书签
        bookmarks.push({
          ...message.bookmark,
          timestamp: new Date().getTime()
        });
        
        // 保存更新后的书签
        localStorage.setItem(message.key, JSON.stringify(bookmarks));
        
        if (sendResponse) {
          sendResponse({ success: true });
        }
      } catch (error) {
        console.error("保存到localStorage失败:", error);
        if (sendResponse) {
          sendResponse({ success: false, error: error.message });
        }
      }
    }
  } catch (error) {
    console.error("内容脚本处理消息失败:", error);
    if (sendResponse) {
      sendResponse({ success: false, error: error.message });
    }
  }
  
  // 返回true以支持异步sendResponse
  return true;
});

// 检查chrome.storage.local中的暂存书签并发送到应用
function checkPendingBookmarks() {
  // 首先检查新的存储键
  const storageKey = "markhub_pending_ai_bookmarks";
  chrome.storage.local.get(storageKey, (data) => {
    if (data[storageKey] && Array.isArray(data[storageKey]) && data[storageKey].length > 0) {
      console.log(`MarkHub扩展: 从${storageKey}中找到${data[storageKey].length}个暂存书签，发送给应用`);
      
      // 发送暂存的书签到应用
      window.postMessage({
        type: "NEW_BOOKMARK_FOR_AI_CLASSIFICATION_BATCH",
        payload: data[storageKey].map(bookmark => ({
          url: bookmark.url,
          title: bookmark.title,
          addedAt: bookmark.createdAt || bookmark.timestamp || new Date().toISOString(),
          tags: bookmark.tags || [],
          description: bookmark.description || ""
        })),
        source: "markhub-extension"
      }, "*");
      
      // 发送后清除暂存的书签
      chrome.storage.local.remove(storageKey, () => {
        console.log(`MarkHub扩展: 暂存书签已从${storageKey}中清除`);
      });

      return; // 已处理新的存储键，不需要检查旧的
    }

    // 如果新的存储键中没有书签，则检查旧的存储键（向后兼容）
    chrome.storage.local.get("pendingBookmarks", (oldData) => {
      if (oldData.pendingBookmarks && Array.isArray(oldData.pendingBookmarks) && oldData.pendingBookmarks.length > 0) {
        console.log(`MarkHub扩展: 从旧存储键中找到${oldData.pendingBookmarks.length}个暂存书签，发送给应用`);
        
        // 发送暂存的书签到应用
        window.postMessage({
          type: "NEW_BOOKMARK_FOR_AI_CLASSIFICATION_BATCH",
          payload: oldData.pendingBookmarks.map(bookmark => ({
            url: bookmark.url,
            title: bookmark.title,
            addedAt: bookmark.createdAt || bookmark.timestamp || new Date().toISOString(),
            tags: bookmark.tags || [],
            description: bookmark.description || ""
          })),
          source: "markhub-extension"
        }, "*");
        
        // 发送后清除暂存的书签
        chrome.storage.local.remove("pendingBookmarks", () => {
          console.log("MarkHub扩展: 旧版暂存书签已从存储中清除");
        });
      }
    });
  });
}

// 页面加载完成后执行
window.addEventListener('load', () => {
  // 初始化通知，告知页面扩展已加载
  window.postMessage({
    type: "MARKHUB_EXTENSION_LOADED",
    source: "markhub-extension"
  }, "*");
  
  console.log("MarkHub 浏览器扩展内容脚本已加载");
  
  // 延迟一小段时间后检查暂存书签，确保应用已准备好接收消息
  setTimeout(checkPendingBookmarks, 1000);
});